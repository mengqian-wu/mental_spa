//salt
var passsword_salt = "ci2t_h0ac2katho3n"