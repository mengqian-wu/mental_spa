package cit59x.hackathon.mental_placeblog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MentalPlaceblogApplication {

    public static void main(String[] args) {
        SpringApplication.run(MentalPlaceblogApplication.class, args);
    }


}
