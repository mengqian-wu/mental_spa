package cit59x.hackathon.mental_placeblog.serviceTest;

public class TaskServiceTest {
    public static void main(String[] args) {
        //TaskSevice taskSevice = new TaskSevice(quoteRepository);
        //System.out.println(taskSevice.getQuote());
    }
}
