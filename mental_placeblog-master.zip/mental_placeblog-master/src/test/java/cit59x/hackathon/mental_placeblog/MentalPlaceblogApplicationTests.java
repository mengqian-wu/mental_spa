package cit59x.hackathon.mental_placeblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MentalPlaceblogApplicationTests {

    @Test
    void contextLoads() {
    }

}
